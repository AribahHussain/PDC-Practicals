﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

class Server
{
    static void Main()
    {
        TcpListener server = new TcpListener(IPAddress.Any, 5000);
        server.Start();
        Console.WriteLine("Server started. Waiting for client...");

        TcpClient client = server.AcceptTcpClient();
        NetworkStream stream = client.GetStream();

        byte[] buffer = new byte[1024];
        int bytesRead = stream.Read(buffer, 0, buffer.Length);

        string sentence = Encoding.UTF8.GetString(buffer, 0, bytesRead);
        Console.WriteLine("Received sentence: " + sentence);

        int wordCount = sentence.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Length;

        byte[] response = Encoding.UTF8.GetBytes(wordCount.ToString());
        stream.Write(response, 0, response.Length);

        client.Close();
        server.Stop();
        Console.WriteLine("Server stopped.");
    }
}
