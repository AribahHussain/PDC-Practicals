﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

class Server
{
    static void Main()
    {
        TcpListener listener = new TcpListener(IPAddress.Any, 5000);
        listener.Start();
        Console.WriteLine("Server running...");

        while (true)
        {
            TcpClient client = listener.AcceptTcpClient();
            NetworkStream ns = client.GetStream();


            byte[] unitData = new byte[1024];
            int unitBytes = ns.Read(unitData, 0, unitData.Length);
            string unit = Encoding.UTF8.GetString(unitData, 0, unitBytes).Trim().ToUpper();


            byte[] tempData = new byte[1024];
            int tempBytes = ns.Read(tempData, 0, tempData.Length);
            string tempInput = Encoding.UTF8.GetString(tempData, 0, tempBytes);
            double tempValue = double.Parse(tempInput);


            double convertedTemp;
            string result;

            if (unit == "C")
            {
                convertedTemp = (tempValue * 9 / 5) + 32;
                result = $"{tempValue}°C = {convertedTemp}°F";
            }
            else if (unit == "F")
            {
                convertedTemp = (tempValue - 32) * 5 / 9;
                result = $"{tempValue}°F = {convertedTemp}°C";
            }
            else
            {
                result = "Invalid unit entered!";
            }


            byte[] sendData = Encoding.UTF8.GetBytes(result);
            ns.Write(sendData, 0, sendData.Length);

            ns.Close();
            client.Close();

            Console.WriteLine("Result sent to client");
        }
    }
}

