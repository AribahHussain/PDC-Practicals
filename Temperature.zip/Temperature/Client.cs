﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

class Client
{
    static void Main()
    {
        TcpClient client = new TcpClient("127.0.0.1", 5000);
        NetworkStream ns = client.GetStream();


        Console.Write("Enter unit (C/F): ");
        string unit = Console.ReadLine();
        byte[] unitData = Encoding.UTF8.GetBytes(unit);
        ns.Write(unitData, 0, unitData.Length);


        Console.Write("Enter temperature: ");
        string temp = Console.ReadLine();
        byte[] tempData = Encoding.UTF8.GetBytes(temp);
        ns.Write(tempData, 0, tempData.Length);


        byte[] buffer = new byte[1024];
        int bytes = ns.Read(buffer, 0, buffer.Length);
        Console.WriteLine("\n" + Encoding.UTF8.GetString(buffer, 0, bytes));

        ns.Close();
        client.Close();
    }
}